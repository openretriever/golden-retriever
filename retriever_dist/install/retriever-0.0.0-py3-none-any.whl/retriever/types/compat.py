from dataclasses import dataclass
from typing import Optional, Union, TYPE_CHECKING

if TYPE_CHECKING:
    from retriever.flow.clock import Clock


@dataclass
class FRPConfig:
    """
    Declarative FRP Policy.
    
    Acts as the "Functional Form" of flow configuration, defining specific
    constraints and behaviors (Rate, Buffering, Feedback) without instantiating
    runtime mechanisms.
    
    vs Clock:
    - FRPConfig: Declarative data ("I need 30Hz")
    - Clock: Runtime mechanism ("I am checking the time loop")
    """

    rate: Optional[Union[str, float]] = None
    trigger: Optional[str] = None
    feedback_from: Optional[str] = None
    feedback_to: Optional[str] = None
    buffer_size: int = 100
    reactive: bool = False

    def as_clock(self) -> 'Clock':
        """
        Convert this declarative policy into a runtime Clock mechanism.
        
        Returns:
            A configured Clock instance (Rate, Trigger, or similar).
        """
        # Lazy import to avoid circular dependency (types -> flow -> types)
        from retriever.flow.clock import Rate, Trigger
        
        if self.trigger:
            return Trigger(on=self.trigger)
            
        hz = self.rate_hz()
        if hz is not None:
            return Rate(hz=hz)
            
        # Default fallback if no timing info provided
        return Trigger(on="tick")

    def rate_hz(self) -> Optional[float]:
        """Return rate as Hz if available, parsing string formats when needed."""
        r = self.rate
        if r is None:
            return None
        if isinstance(r, (int, float)):
            return float(r)
        rs = str(r).strip().lower()
        try:
            if rs.endswith("hz"):
                return float(rs[:-2])
            if rs.endswith("ms"):
                ms = float(rs[:-2])
                return 1000.0 / ms if ms > 0 else None
            if rs.endswith("s"):
                s = float(rs[:-1])
                return 1.0 / s if s > 0 else None
            return float(rs)
        except Exception:
            return None
