"""
Performance Benchmarking Infrastructure for Retriever Runtime.

This module provides tools to measure and compare performance between
different execution backends (e.g. Multiprocessing vs Dora).
"""

import time
import psutil
import statistics
import json
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Union
from contextlib import contextmanager

from retriever.rt.runtime import execute_ir
from retriever.ir import IR
from retriever.ir.execution import ExecutionGraph


@dataclass
class BenchmarkResult:
    """Container for benchmark execution results."""
    name: str
    backend: str
    duration: float
    memory_peak_mb: float
    memory_avg_mb: float
    throughput: float = 0.0
    success_rate: float = 1.0
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class BenchmarkSuite:
    """Collection of benchmark results for comparison."""
    results: List[BenchmarkResult] = field(default_factory=list)
    timestamp: str = field(default_factory=lambda: time.strftime("%Y-%m-%d %H:%M:%S"))

    def add_result(self, result: BenchmarkResult) -> None:
        self.results.append(result)

    def get_speedup(self, baseline_name: str, comparison_name: str) -> Optional[float]:
        """Calculate speedup between two benchmarks (baseline / comparison)."""
        baseline = next((r for r in self.results if r.name == baseline_name), None)
        comparison = next((r for r in self.results if r.name == comparison_name), None)
        
        if baseline and comparison and comparison.duration > 0:
            return baseline.duration / comparison.duration
        return None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "timestamp": self.timestamp,
            "results": [
                {
                    "name": r.name,
                    "backend": r.backend,
                    "duration": r.duration,
                    "memory_peak_mb": r.memory_peak_mb,
                    "memory_avg_mb": r.memory_avg_mb,
                    "throughput": r.throughput,
                    "success_rate": r.success_rate,
                    "metadata": r.metadata
                }
                for r in self.results
            ]
        }


class PerformanceBenchmarker:
    """
    Benchmarking system for comparing runtime backends.
    """

    def __init__(self, output_file: Optional[str] = None):
        self.suite = BenchmarkSuite()
        self.output_file = output_file

    def benchmark_pipeline(
        self,
        ir: Union[IR, ExecutionGraph],
        name: str,
        duration: float = 5.0,
        backends: List[str] = None,
    ):
        """
        Benchmark a pipeline execution on multiple backends.

        Args:
            ir: Pipeline definition (IR or ExecutionGraph)
            name: Benchmark name
            duration: Time to run the pipeline in seconds
            backends: List of backends to test (default: ['multiprocessing', 'dora'])
        """
        if backends is None:
            backends = ["multiprocessing", "dora"]

        print(f"\nBenchmarking Pipeline: {name}")
        print("-" * 40)

        results_map = {}

        for backend in backends:
            print(f"Testing backend: {backend}...")
            
            try:
                result = self._run_benchmark(ir, f"{name}_{backend}", backend, duration)
                self.suite.add_result(result)
                results_map[backend] = result
                print(f"  Duration: {result.duration:.2f}s")
                print(f"  Throughput: {result.throughput:.2f} ops/sec")
                print(f"  Memory Peak: {result.memory_peak_mb:.1f} MB")
            except Exception as e:
                print(f"  FAILED: {e}")

        # specific check: if we have both multiprocessing and dora, print speedup
        if "multiprocessing" in results_map and "dora" in results_map:
            mp_res = results_map["multiprocessing"]
            dora_res = results_map["dora"]
            speedup = mp_res.duration / dora_res.duration if dora_res.duration > 0 else 0
            print(f"\nSpeedup (MP vs Dora): {speedup:.2f}x")

        if self.output_file:
            self._save_results()

    def _run_benchmark(
        self,
        ir: Union[IR, ExecutionGraph],
        name: str,
        backend: str,
        duration: float
    ) -> BenchmarkResult:
        with self._memory_monitor() as mem_tracker:
            start_time = time.time()
            
            # Execute pipeline
            # Note: execute_ir returns the engine/scheduler used
            engine = execute_ir(
                ir,
                backend=backend,
                duration=duration,
                blocking=True,
                log_config=None  # Default logging
            )
            
            actual_duration = time.time() - start_time

        # Calculate metrics
        peak_mb = max(mem_tracker.measurements) if mem_tracker.measurements else 0.0
        avg_mb = statistics.mean(mem_tracker.measurements) if mem_tracker.measurements else 0.0
        
        # Estimate throughput (ops/sec) - this is approximate as we don't count exact "ops" inside execute_ir yet
        # For now, we use a placeholder or derived metric if available from engine
        throughput = 0.0 
        if hasattr(engine, 'scheduler') and hasattr(engine.scheduler, 'iteration_count'):
             throughput = engine.scheduler.iteration_count / actual_duration

        return BenchmarkResult(
            name=name,
            backend=backend,
            duration=actual_duration,
            memory_peak_mb=peak_mb,
            memory_avg_mb=avg_mb,
            throughput=throughput,
            success_rate=1.0, # Assumed 1.0 if no exception raised
            metadata={"requested_duration": duration}
        )

    @contextmanager
    def _memory_monitor(self):
        """Monitor memory usage of current process and children."""
        class MemoryTracker:
            def __init__(self):
                self.measurements = []
                self.process = psutil.Process()
                self._stop = False

            def start(self):
                import threading
                def monitor():
                    while not self._stop:
                        try:
                            mem = self.process.memory_info().rss / 1024 / 1024
                            # Add child processes
                            for child in self.process.children(recursive=True):
                                try:
                                    mem += child.memory_info().rss / 1024 / 1024
                                except (psutil.NoSuchProcess, psutil.AccessDenied):
                                    pass
                            self.measurements.append(mem)
                        except Exception:
                            pass
                        time.sleep(0.1)

                self.thread = threading.Thread(target=monitor)
                self.thread.start()

            def stop(self):
                self._stop = True
                self.thread.join()

        tracker = MemoryTracker()
        tracker.start()
        try:
            yield tracker
        finally:
            tracker.stop()

    def _save_results(self):
        if not self.output_file:
            return
        with open(self.output_file, "w") as f:
            json.dump(self.suite.to_dict(), f, indent=2)
        print(f"Results saved to {self.output_file}")
