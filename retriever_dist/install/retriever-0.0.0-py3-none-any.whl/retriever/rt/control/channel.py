"""
Control channel for communicating between control plane and data plane.

The ControlChannel provides a backend-agnostic way for control signals
to reach executors and flows during pipeline execution.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, Optional
import time
import uuid


class ControlCommand(Enum):
    """Control commands that can be sent to flows/executors."""
    PAUSE = "pause"
    RESUME = "resume"
    RESET = "reset"
    STOP = "stop"
    GET_STATE = "get_state"
    SET_CONFIG = "set_config"
    LOG_OUTPUT = "log_output"  # Flow stdout/stderr output for web UI


@dataclass
class ControlMessage:
    """
    A control message sent through the ControlChannel.

    Attributes:
        command: The control command to execute
        target: Optional target node_id (None = all nodes)
        payload: Optional command-specific data
        timestamp: When the command was issued
        request_id: Unique ID for request/response correlation
    """
    command: ControlCommand
    target: Optional[str] = None  # None means "all flows"
    payload: Optional[Dict[str, Any]] = None
    timestamp: float = field(default_factory=lambda: time.time())
    request_id: str = field(default_factory=lambda: str(uuid.uuid4()))


@dataclass
class ControlResponse:
    """Response to a control message."""
    request_id: str
    node_id: str
    success: bool
    data: Optional[Dict[str, Any]] = None
    error: Optional[str] = None
    timestamp: float = field(default_factory=lambda: time.time())


class ControlChannel(ABC):
    """
    Abstract base class for control channels.

    Control channels provide bidirectional communication between:
    - PipelineController (control plane)
    - Executors/Flows (data plane)

    Different backends implement this differently:
    - In-process: Direct method calls or thread-safe queues
    - Multiprocessing: multiprocessing.Queue + shared memory
    - Dora: Dora's built-in control messages or dedicated control node
    """

    @abstractmethod
    def send_command(self, message: ControlMessage) -> None:
        """Send a control command (non-blocking)."""
        pass

    @abstractmethod
    def receive_command(self, timeout: float = 0.0) -> Optional[ControlMessage]:
        """Receive a control command (blocking with timeout)."""
        pass

    @abstractmethod
    def send_response(self, response: ControlResponse) -> None:
        """Send a response back to the controller."""
        pass

    @abstractmethod
    def receive_response(self, timeout: float = 1.0) -> Optional[ControlResponse]:
        """Receive a response from an executor."""
        pass

    @abstractmethod
    def close(self) -> None:
        """Close the channel and release resources."""
        pass

    def send_log(self, message: ControlMessage) -> None:
        """
        Send a log message to dashboard consumers.

        Default behavior falls back to command transport for backward compatibility.
        """
        self.send_command(message)

    def receive_log(self, timeout: float = 0.0) -> Optional[ControlMessage]:
        """
        Receive a log message.

        Default behavior falls back to command transport.
        """
        message = self.receive_command(timeout=timeout)
        if message and message.command == ControlCommand.LOG_OUTPUT:
            return message
        return None


class MPControlChannel(ControlChannel):
    """
    Multiprocessing-based control channel using Queues.

    Uses per-node command queues to avoid message routing issues:
    - command_queues: Dict[node_id, Queue] - Controller -> specific Executor
    - broadcast_queue: Queue - Controller -> all Executors (for target=None commands)
    - response_queue: Queue - Executors -> Controller (shared)

    Note: Queues can only be shared through inheritance (fork), not pickling.
    """

    def __init__(self, command_queue=None, response_queue=None, log_queue=None):
        import multiprocessing
        self._response_queue = response_queue or multiprocessing.Queue()
        self._log_queue = log_queue or multiprocessing.Queue()
        # Per-node queues: registered before fork via register_node()
        self._node_command_queues: dict = {}
        # Fallback/per-executor command queue (used when constructed inside executor process)
        self._broadcast_queue = command_queue or multiprocessing.Queue()

    def register_node(self, node_id: str):
        """Register a node and create its dedicated command queue. Call before fork."""
        import multiprocessing
        if node_id not in self._node_command_queues:
            self._node_command_queues[node_id] = multiprocessing.Queue()

    def get_node_command_queue(self, node_id: str):
        """Get the command queue for a specific node (for executor to read from)."""
        return self._node_command_queues.get(node_id, self._broadcast_queue)

    @property
    def command_queue(self):
        """
        Legacy compatibility queue.

        Dora backend currently expects a single command queue handle.
        """
        return self._broadcast_queue

    @property
    def response_queue(self):
        return self._response_queue

    @property
    def log_queue(self):
        return self._log_queue

    def send_command(self, message: ControlMessage) -> None:
        """Send command - routes to specific node queue or broadcasts to all."""
        if message.command == ControlCommand.LOG_OUTPUT:
            self.send_log(message)
            return

        if message.target and message.target in self._node_command_queues:
            self._node_command_queues[message.target].put(message, block=False)
        elif message.target is None:
            # Broadcast: send to all registered node queues
            for queue in self._node_command_queues.values():
                queue.put(message, block=False)
        else:
            # Unknown target: use broadcast queue
            self._broadcast_queue.put(message, block=False)

    def receive_command(self, timeout: float = 0.0) -> Optional[ControlMessage]:
        """Read from broadcast queue (used for unregistered nodes)."""
        try:
            return self._broadcast_queue.get(block=True, timeout=timeout)
        except Exception:
            return None

    def send_response(self, response: ControlResponse) -> None:
        self._response_queue.put(response, block=False)

    def receive_response(self, timeout: float = 1.0) -> Optional[ControlResponse]:
        try:
            return self._response_queue.get(block=True, timeout=timeout)
        except Exception:
            return None

    def send_log(self, message: ControlMessage) -> None:
        self._log_queue.put(message, block=False)

    def receive_log(self, timeout: float = 0.0) -> Optional[ControlMessage]:
        try:
            return self._log_queue.get(block=True, timeout=timeout)
        except Exception:
            return None

    def close(self) -> None:
        for q in self._node_command_queues.values():
            q.close()
        self._broadcast_queue.close()
        self._log_queue.close()
        self._response_queue.close()


class InProcessControlChannel(ControlChannel):
    """
    In-process control channel for Pipeline.step() debugging.

    Uses simple thread-safe queues since everything runs in one process.
    """

    def __init__(self):
        from queue import Queue
        self._command_queue = Queue()
        self._response_queue = Queue()
        self._log_queue = Queue()

    def send_command(self, message: ControlMessage) -> None:
        if message.command == ControlCommand.LOG_OUTPUT:
            self.send_log(message)
            return
        self._command_queue.put(message)

    def receive_command(self, timeout: float = 0.0) -> Optional[ControlMessage]:
        from queue import Empty
        try:
            return self._command_queue.get(block=True, timeout=timeout)
        except Empty:
            return None

    def send_response(self, response: ControlResponse) -> None:
        self._response_queue.put(response)

    def receive_response(self, timeout: float = 1.0) -> Optional[ControlResponse]:
        from queue import Empty
        try:
            return self._response_queue.get(block=True, timeout=timeout)
        except Empty:
            return None

    def send_log(self, message: ControlMessage) -> None:
        self._log_queue.put(message)

    def receive_log(self, timeout: float = 0.0) -> Optional[ControlMessage]:
        from queue import Empty
        try:
            return self._log_queue.get(block=True, timeout=timeout)
        except Empty:
            return None

    def close(self) -> None:
        pass  # Python queues don't need explicit close
