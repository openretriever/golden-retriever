"""
pi.dev-compatible typed command gateway for Retriever control operations.

This keeps command dispatch logic separate from the web transport so it can be
used by Web APIs, RPC shims, or future pi-agent integrations.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple
import uuid


@dataclass(frozen=True)
class CommandSpec:
    command_type: str
    required_capabilities: Tuple[str, ...]
    summary: str
    payload_schema: Dict[str, Any]


class PiCommandGateway:
    """Typed command dispatcher with capability checks and idempotency cache."""

    COMMANDS: Dict[str, CommandSpec] = {
        "Run.Pause": CommandSpec(
            command_type="Run.Pause",
            required_capabilities=("run:pause",),
            summary="Pause entire pipeline or a single flow.",
            payload_schema={
                "type": "object",
                "properties": {
                    "node_id": {"type": "string"},
                },
                "additionalProperties": False,
            },
        ),
        "Run.Resume": CommandSpec(
            command_type="Run.Resume",
            required_capabilities=("run:resume",),
            summary="Resume entire pipeline or a single flow.",
            payload_schema={
                "type": "object",
                "properties": {
                    "node_id": {"type": "string"},
                },
                "additionalProperties": False,
            },
        ),
        "Run.Reset": CommandSpec(
            command_type="Run.Reset",
            required_capabilities=("run:reset",),
            summary="Reset entire pipeline or a single flow.",
            payload_schema={
                "type": "object",
                "properties": {
                    "node_id": {"type": "string"},
                },
                "additionalProperties": False,
            },
        ),
        "Run.Stop": CommandSpec(
            command_type="Run.Stop",
            required_capabilities=("run:stop",),
            summary="Stop pipeline or a single flow.",
            payload_schema={
                "type": "object",
                "properties": {
                    "node_id": {"type": "string"},
                },
                "additionalProperties": False,
            },
        ),
        "Trace.Query": CommandSpec(
            command_type="Trace.Query",
            required_capabilities=("trace:query",),
            summary="Query current control-plane state as a trace/status snapshot.",
            payload_schema={
                "type": "object",
                "properties": {
                    "node_id": {"type": "string"},
                },
                "additionalProperties": False,
            },
        ),
    }

    def __init__(self, controller: Any) -> None:
        self._controller = controller
        self._idempotency_cache: Dict[str, Dict[str, Any]] = {}

    def schema(self) -> Dict[str, Any]:
        """Return tool schema for pi.dev clients."""
        commands = []
        for spec in self.COMMANDS.values():
            commands.append(
                {
                    "type": spec.command_type,
                    "required_capabilities": list(spec.required_capabilities),
                    "summary": spec.summary,
                    "payload_schema": spec.payload_schema,
                }
            )
        return {
            "version": "v1",
            "commands": commands,
        }

    def execute(self, envelope: Dict[str, Any]) -> Dict[str, Any]:
        """Execute a typed command envelope."""
        command_id = str(envelope.get("command_id") or f"cmd_{uuid.uuid4().hex[:12]}")
        idempotency_key = envelope.get("idempotency_key")

        if idempotency_key:
            cached = self._idempotency_cache.get(idempotency_key)
            if cached is not None:
                return dict(cached)

        command = envelope.get("command") or {}
        command_type = command.get("type")
        payload = command.get("payload") or {}
        capabilities = envelope.get("capabilities") or []

        spec = self.COMMANDS.get(command_type)
        if spec is None:
            result = self._error(
                command_id=command_id,
                code="UNKNOWN_COMMAND_TYPE",
                message=f"Unknown command type: {command_type}",
                remediation="Call /v1/commands/schema and select a supported command type.",
            )
            self._cache_if_needed(idempotency_key, result)
            return result

        missing = [cap for cap in spec.required_capabilities if cap not in capabilities]
        if missing:
            result = self._error(
                command_id=command_id,
                code="CAPABILITY_DENIED",
                message=f"Missing capabilities: {', '.join(missing)}",
                remediation="Re-authenticate with required capabilities in envelope.capabilities.",
            )
            self._cache_if_needed(idempotency_key, result)
            return result

        try:
            result_payload = self._dispatch(command_type, payload)
            response = {
                "ok": True,
                "command_id": command_id,
                "result": result_payload,
                "audit_event_id": self._new_audit_event_id(),
            }
        except Exception as exc:
            response = self._error(
                command_id=command_id,
                code="COMMAND_EXECUTION_FAILED",
                message=str(exc),
                remediation="Inspect runtime logs and retry with corrected payload.",
            )

        self._cache_if_needed(idempotency_key, response)
        return response

    def _dispatch(self, command_type: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        node_id = payload.get("node_id")
        run_id = self._run_handle()

        if command_type == "Run.Pause":
            success = self._controller.pause(node_id)
            return {"run_id": run_id, "node_id": node_id, "paused": bool(success)}

        if command_type == "Run.Resume":
            success = self._controller.resume(node_id)
            return {"run_id": run_id, "node_id": node_id, "resumed": bool(success)}

        if command_type == "Run.Reset":
            success = self._controller.reset(node_id)
            return {"run_id": run_id, "node_id": node_id, "reset": bool(success)}

        if command_type == "Run.Stop":
            success = self._controller.stop(node_id)
            return {"run_id": run_id, "node_id": node_id, "stopped": bool(success)}

        if command_type == "Trace.Query":
            status = self._controller.get_state(node_id)
            snapshot = status.to_dict() if hasattr(status, "to_dict") else self._status_fallback(status)
            snapshot_handle = f"trace_{int(datetime.now(timezone.utc).timestamp() * 1000)}"
            return {
                "run_id": run_id,
                "trace_segment_id": snapshot_handle,
                "snapshot": snapshot,
            }

        raise ValueError(f"Command not implemented: {command_type}")

    def _status_fallback(self, status: Any) -> Dict[str, Any]:
        nodes = getattr(status, "nodes", {})
        if isinstance(nodes, dict):
            node_dict: Dict[str, Any] = {}
            for node_id, node_status in nodes.items():
                if hasattr(node_status, "to_dict"):
                    node_dict[node_id] = node_status.to_dict()
                elif isinstance(node_status, dict):
                    node_dict[node_id] = dict(node_status)
                else:
                    node_dict[node_id] = {"state": str(node_status)}
        else:
            node_dict = {}
        return {
            "name": getattr(status, "name", "unknown"),
            "state": getattr(status, "state", "unknown"),
            "node_count": getattr(status, "node_count", len(node_dict)),
            "nodes": node_dict,
        }

    def _run_handle(self) -> str:
        pipeline_name = getattr(self._controller, "_name", "pipeline")
        return f"run::{pipeline_name}"

    def _new_audit_event_id(self) -> str:
        return f"aud_{uuid.uuid4().hex[:12]}"

    def _cache_if_needed(self, idempotency_key: Optional[str], response: Dict[str, Any]) -> None:
        if idempotency_key:
            self._idempotency_cache[idempotency_key] = dict(response)

    def _error(self, command_id: str, code: str, message: str, remediation: str) -> Dict[str, Any]:
        return {
            "ok": False,
            "command_id": command_id,
            "result": {},
            "audit_event_id": self._new_audit_event_id(),
            "error": {
                "code": code,
                "message": message,
                "remediation_hint": remediation,
            },
        }

